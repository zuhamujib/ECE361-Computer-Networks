// Task: open a UDP socket and and send message at the specified port
// Some notes: This lab focuses on UDP, which are messgae-oriented i.e. one call
// from the transmitter corresponds to one call to the reciever
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <time.h>
#include <math.h>

#include "packet.h"

#define FILE_LEN 256
#define INPUT_LEN 128
#define NUM_FRAGMENTS 1000

// Lab 1
/*
To start communication with a client:
     1. Create a socket
         a. int socket(int domain, int type, int protocol);
     2. Get the server address info
     3. Ask user for input from the terminal
     4. Send the messgage
     5. Wait for the response from the server
     6. Handle the server response
        a. Success! -> 7.
        b. Failure:( -> 10.
     7. Find the file size
     8. Segment into packets of size 1000 bytes
     9. Send packet stop-and-wait for acknowledgement
     10. Close the socket
*/


// Lab 2
/*
Please remember that while the beginning of the packet is in fact just plain text, the data
portion of the packet may in fact contain binary data. This means that you should not use
string manipulation functions available in C for the data field or for the whole packet. Only
the first part of the packet before data is really a string.
*/

// JUST SOME ADDITIONAL NOTES
// remember: argv[0] contains the name of the current program (exe)

// these arguments will be passed in through the terminal on runtime
// deliver <server address> <server port number>

int main(int argc, char* argv[]) {
    // STEP 1 **********************************************************************

    if (argc < 2) {
        perror("INVALID EXECUTION COMMAND\n");
        exit(1);
    }
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);    // we used SOCK_DGRAM for UDP

    // From Beej's section 5.3
    if (sockfd < 0) {
        perror("error creating socket\n");  // possibly fix this error more later
    }

    // STEP 2 **********************************************************************

    struct in_addr server_address;
    inet_pton(AF_INET, argv[1], &server_address);
    int server_port = atoi(argv[2]);

    if (server_port < 0) {
        perror("Invalid port number\n");
        exit(EXIT_FAILURE);
    }
 
    printf("Number of arguments: %d\n", argc);

    for (int i = 0; i < argc; i++) {
        printf("Argument %d: %s\n", i, argv[i]);
    }

    struct sockaddr_in socket_addr;
    memset(&socket_addr, 0, sizeof(socket_addr));  // initialize the mem to 0
    socket_addr.sin_family = AF_INET;              // internet address family
    socket_addr.sin_port = htons(server_port);
    socket_addr.sin_addr = server_address;

    // STEP 3 **********************************************************************

    char filename[INPUT_LEN];
    char ftp[INPUT_LEN];
    char input[FILE_LEN];   // reading the full user input

    long RTT = 0.0;
    struct timespec start_time , end_time;

    while (1) {     // Read user input constantly until a correct input is input format is given
        printf("Enter the message to be sent in the format: ftp <filename>\n");

        if (fgets(input, sizeof(input), stdin) != NULL) {
            input[strcspn(input, "\n")] = '\0'; // m,aking sure to remove any enldine characters instead ending it with a eof character for string

            if (sscanf(input, "%255s %255s", ftp, filename) == 2 && strcmp(ftp, "ftp") == 0) {  // Parse the input and check for exactly two inputs
                // printf("Input 1: %s\n", ftp);
                // printf("Input 2: %s\n", filename);
                break;
            } else {
                printf("Incorrect format of input.\n");
            }
        } else {
            printf("Failed to read input.\n");
        }
        fflush(stdin);  // restting the user input so no errors happen
    }

    if (access(filename, F_OK) != 0) {  // checking if the filename entered even exists
        printf("filename does not exist.\n");
        exit(1);
    }

    // STEP 4 **********************************************************************

    printf("Sending message to server.\n");
    ssize_t bytes_sent = sendto(sockfd, ftp, strlen(ftp), 0, (struct sockaddr*)&socket_addr, sizeof(socket_addr));
    if (bytes_sent < 0) {
        printf("Error sending message to server.\n");
        exit(1);
    }

    // STEP 5 **********************************************************************

    char message_recieved[FILE_LEN];
    struct sockaddr_in from_addr;
    socklen_t from_len = sizeof(from_addr);
    printf("Waiting message from server.\n");   // waiting for server response
    ssize_t bytes_recieved = recvfrom(sockfd, &message_recieved, sizeof(message_recieved), 0, (struct sockaddr*)&from_addr, &from_len);
    if (bytes_recieved < 0) {
        printf("Error recieving message from server.\n");
        exit(1);
    }

    // STEP 6 **********************************************************************

    message_recieved[bytes_recieved] = '\0';  // adding a null character at the end to represent a string

    if (strcmp(message_recieved, "yes") == 0) {
        printf("A file transfer can start.\n");
    } else {
        perror("Error recieveing message\n");
        exit(1);
    }

    // STEP 7 - 9 **********************************************************************
    printf("here1\n");
    fflush(stdout);
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error reading file.\n");
        return -1;
    }

    char buffer[NUM_FRAGMENTS] = {0};    // char is 1 byte
    char send_buffer[NUM_FRAGMENTS + 100];  // the buffer storing the file header and the data combined ro be sent as a packet
    int num_packets = 1;
    size_t size;
    int retry = 0;

    fseek(file, 0 , SEEK_END);  // finding the file size in bytes
    size_t total_bytes = ftell(file);
    size_t total_frags = (total_bytes + NUM_FRAGMENTS - 1) / NUM_FRAGMENTS; // finding the total number of packets to be sent
    rewind(file);  // Move file pointer back to the start

    printf("Total number of fragments: %d\n", total_frags);

    while (!feof(file)) {
        if (!retry) {
            size = fread(buffer, 1, NUM_FRAGMENTS, file); // reading the next 1000 bytes considering the last one sent was a pass
        }

        // printf("here2\n");
        // fflush(stdout);
        struct packet pack; // build a packet
        pack.total_frag = total_frags;
        pack.frag_no = num_packets;
        pack.size = size;

        // printf("here2.5\n");
        // fflush(stdout);
        // strcpy(pack.filename, filename);
        
        pack.filename = malloc(strlen(filename) + 1);  // Allocate memory (+1 for '\0')
        if (pack.filename == NULL) {
            perror("Memory allocation failed");
            exit(1);
        }

        // printf("here2.5\n");
        memcpy(pack.filename, filename, strlen(filename) + 1);  // copy filename into the packet
        // printf("here2.6\n");
        memcpy(pack.filedata, buffer, size); // copy the file data to pack.filedata

        // printf("File data: \n");
        /*
        for (int i = 0; i < size; i++) {
            printf("%c", pack.filedata[i]);
        }
        */
        int header = snprintf(send_buffer, sizeof(send_buffer), "%u:%u:%u:%s:", pack.total_frag, pack.frag_no, pack.size, pack.filename);   // putting together the buffer to send all thr packet data
    
        memcpy(send_buffer + header, pack.filedata, pack.size); // copying the file data into memory after the header

        // printf("here3\n");
        // fflush(stdout);
        /*
        time_t ltime;
        if(time(&ltime) == -1)
        {
            printf("Calendar time not available.\n");
            exit(1);
        }
        printf("The time is %s\n", ctime(&ltime));
        */

        // printf("Sending message to server.\n");  // send the packet to server
        clock_gettime(CLOCK_MONOTONIC, &start_time);
        printf("-------------------------------------------Sending packet %d to server---------------------------------\n", num_packets);
        ssize_t bytes_sent = sendto(sockfd, send_buffer, sizeof(send_buffer), 0, (struct sockaddr*)&socket_addr, sizeof(socket_addr));
        if (bytes_sent < 0) {
            printf("Error sending message to server.\n");
            exit(1);
        }

        bytes_recieved = recvfrom(sockfd, &message_recieved, sizeof(message_recieved), 0, (struct sockaddr*)&from_addr, &from_len); // wait for acknowledgement
        if (bytes_recieved < 0) {
            printf("Error recieving message from server.\n");
            exit(1);
        }
        clock_gettime(CLOCK_MONOTONIC, &end_time);

        RTT = fmax(RTT, (end_time.tv_sec - start_time.tv_sec) * 1000000000 + (end_time.tv_nsec - start_time.tv_nsec));    // calculating the round trip time by taking the difference

        message_recieved[bytes_recieved] = '\0';  // adding a null character at the end to represent a string
        
        // printf("here4\n");
        // fflush(stdout);
        unsigned int ack_frag_no;
        printf("Message received: %s\n", message_recieved);
        if (sscanf(message_recieved, "ACK:%u", &ack_frag_no) == 1) {
            if (ack_frag_no == pack.frag_no) {
                printf("packet %d acknowledged\n", num_packets);
                num_packets++;
            }
        } else {
            printf("packet not acknowledged, sending again!\n");
            retry = 1;  // don't read the new packet fragments, try sending the same fragment again
        }
    }

    if (feof(file)) {
        printf("End of file reached.\n");
    } else if (ferror(file)) {
        perror("Error reading file.\n");
    }

    printf("The round trip time is %f us\n", (double) RTT/1000.0);
    fclose(file);   // Close the file

    close(sockfd);  // Close the socket

    return 0;
}